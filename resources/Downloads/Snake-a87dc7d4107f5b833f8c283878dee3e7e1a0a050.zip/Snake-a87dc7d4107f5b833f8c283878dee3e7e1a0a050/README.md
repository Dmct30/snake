# Snake
Snake game in godot 3.3.3
![snake_game_image](/Sprites/snake_game.png?raw=true)
